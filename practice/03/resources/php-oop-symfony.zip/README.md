# PHP OOP Workspace (Symfony)

This workshop is intended for [eMAG](https://www.emag.ro/)
[QA](https://en.wikipedia.org/wiki/Quality_assurance).

See: [liviubalan/php-oop](https://github.com/liviubalan/php-oop).
